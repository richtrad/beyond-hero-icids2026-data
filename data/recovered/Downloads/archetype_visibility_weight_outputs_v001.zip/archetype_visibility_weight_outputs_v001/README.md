# Archetype visibility weighting outputs

Input annotations: `/mnt/data/igdb_archetype_annotations_simple_characters_only_v001 (1).csv`
Input metadata: `/mnt/data/igdb_master_broad_with_steam_llm_overlap_v001.csv`
Rows after min-year filter: 90,387
Rows with positive review visibility: 26,260 (29.1%)

## Weight schemes
- `equal`: each protagonist/game row has weight 1.
- `raw_reviews`: raw Steam review count. Use only as a stress test; megahits dominate.
- `raw_cap_p99`: raw reviews capped at 99th percentile.
- `sqrt_reviews`: intermediate damping.
- `log_reviews`: log1p(review count), strongly damped.
- `log_cap_p99`: log1p(review count), capped at 99th percentile. Recommended visibility model.
- `blend_equal_log`: 50% equal + 50% normalized log visibility.
- `tiered_reviews`: coarse log10 tiers.

## Populations
- `all_rows_missing_visibility_equal`: all rows included; missing review counts get a neutral visibility weight of 1.
- `matched_only`: only rows with positive review visibility included. Better for Steam-linked recent subset; more biased historically.

## Main files
- `merged_rows_with_visibility_weights.csv`
- `year_archetype_shares_by_weight_scheme_long.csv`
- `decade_archetype_shares_by_weight_scheme_long.csv`
- `year_visibility_coverage.csv`
- `linecharts_*_5yr.png`
- `heatmaps_*.png`
- `coverage_by_year.png`
